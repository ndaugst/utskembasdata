<?php

require_once("config.php");

session_start();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (isset($_POST['register'])) {

    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    
    if (strlen($_POST["password"]) < 8 || !preg_match("/[A-Za-z]/", $_POST["password"]) || !preg_match("/[0-9]/", $_POST["password"])) {
        $error = "Password harus minimal 8 karakter, termasuk huruf dan angka.";
    } else {
        $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    }

    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    if (!$email) {
        $error = "Email tidak valid.";
    }

    // Memeriksa apakah username atau email sudah terdaftar
    $sql = "SELECT * FROM users WHERE username=:username OR email=:email";
    $stmt = $db->prepare($sql);
    $stmt->execute([":username" => $username, ":email" => $email]);
    if ($stmt->rowCount() > 0) {
        $error = "Username atau Email kamu sudah terdaftar.";
    }

    // Menyiapkan query untuk memasukkan data ke database
    if (!isset($error)) {
        $sql = "INSERT INTO users (name, username, email, password) 
                VALUES (:name, :username, :email, :password)";
        $stmt = $db->prepare($sql);

        // Bind parameter ke query
        $params = array(
            ":name" => $name,
            ":username" => $username,
            ":password" => $password,
            ":email" => $email
        );

        // Eksekusi query untuk menyimpan ke database
        if ($stmt->execute($params)) {
            header("Location: login.php");
            exit;
        } else {
            $error = "Gagal mendaftar, coba lagi.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>REGISTER GENG KAMBING</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">   
    <style>
        :root {
            --kambing-coklat: #8B4513;
            --kambing-putih: #F5F5DC;
            --kambing-hitam: #000000;
            --kambing-merah: #FF0000;
            --kambing-hijau: #2E8B57;
        }
        body {
            background-color: #f8f9fa;
            background-image: url('img/kambing-bg.jpg');
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }
        .kambing-card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            border: 3px solid var(--kambing-coklat);
            margin-top: 30px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .kambing-header {
            background: var(--kambing-coklat);
            color: white;
            padding: 15px;
            text-align: center;
            border-bottom: 3px solid var(--kambing-hijau);
            border-radius: 12px 12px 0 0;
            margin-bottom: 20px;
        }
        .kambing-title {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .btn-kambing {
            background-color: var(--kambing-coklat);
            color: white;
            border: none;
            padding: 12px;
            font-size: 1.1rem;
            font-weight: bold;
            transition: all 0.3s;
        }
        .btn-kambing:hover {
            background-color: var(--kambing-hijau);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .form-control {
            border: 2px solid var(--kambing-coklat);
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 15px;
        }
        .form-control:focus {
            border-color: var(--kambing-hijau);
            box-shadow: 0 0 0 0.25rem rgba(46, 139, 87, 0.25);
        }
        .kambing-link {
            color: var(--kambing-coklat);
            font-weight: bold;
            text-decoration: none;
        }
        .kambing-link:hover {
            color: var(--kambing-hijau);
            text-decoration: underline;
        }
        .kambing-img {
            border: 5px solid var(--kambing-coklat);
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            max-width: 100%;
            height: auto;
        }
        .kambing-subtitle {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: var(--kambing-coklat);
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="kambing-card">
                <div class="kambing-header">
                    <p><a href="index.php">Home</a></p>
                    <h4 class="kambing-subtitle">Yukkk Join Geng Kambing Kece Multiverseee</h4>
                    <p>Kalo kamu udah punya akun? <a href="login.php">Login di sini yaa</a></p>

                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST">

                        <div class="form-group">
                            <label for="name">Nama Lengkap</label>
                            <input class="form-control" type="text" name="name" placeholder="Nama kamu" required/>
                        </div>

                        <div class="form-group">
                            <label for="username">Username</label>
                            <input class="form-control" type="text" name="username" placeholder="Username" required/>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input class="form-control" type="email" name="email" placeholder="Alamat Email" required/>
                        </div>

                        <div class="form-group">
                            <label for="password">Password</label>
                            <input class="form-control" type="password" name="password" placeholder="Password" required/>
                        </div>

                        <input type="submit" class="btn btn-success btn-block" name="register" value="Daftar" />

                    </form>

                </div>

                <div class="col-md-6">
                    <img class="img img-responsive" src="image/download.jfif" />
                </div>

            </div>
        </div>
    </div>
</div>
</body>
</html>
