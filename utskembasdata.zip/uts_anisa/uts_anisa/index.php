<!DOCTYPE html>
<html lang="en">
<link>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0", >
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kambing n the Gang</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --kambing-coklat: #8B4513;
            --kambing-putih: #F5F5DC;
            --kambing-hitam: #000000;
            --kambing-merah: #FF0000;
            --kambing-hijau: #2E8B57;
        }
        body {
            background-color: #f8f9fa;
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }
        .kambing-jumbotron {
            background-color: var(--kambing-coklat);
            color: white;
            padding: 3rem 1rem;
            margin-bottom: 2rem;
            border-radius: 0;
            border-bottom: 5px solid var(--kambing-hijau);
        }
        .kambing-title {
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        .kambing-subtitle {
            font-size: 1.2rem;
        }
        .btn-kambing {
            background-color: var(--kambing-hijau);
            color: white;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
            margin-left: 10px;
        }
        .btn-kambing-secondary {
            background-color: var(--kambing-coklat);
            color: white;
        }
        .btn-kambing:hover {
            background-color: var(--kambing-coklat);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .btn-kambing-secondary:hover {
            background-color: var(--kambing-hijau);
        }
        .img-kambing {
            max-width: 100%;
            height: auto;
            border: 5px solid var(--kambing-coklat);
            border-radius: 15px;
            margin: 30px 0;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .kambing-section {
            padding: 40px 0;
        }
        .kambing-container {
            max-width: 1200px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <header>
        <div class="kambing-jumbotron jumbotron-fluid">
            <div class="kambing-container container">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h1 class="kambing-title">Selamat Datang Kambingg</h1>
                        <p class="kambing-subtitle">Bergabunglah bersama kambing kece di multiverse</p>
                    </div>
                    <div class="col-md-4">
                        <a href="login.php" class="btn btn-kambing-secondary btn-kambing">Log in</a>
                        <a href="register.php" class="btn btn-kambing">Sign Up</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section>
        <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <img class="img img-responsive" src="image/download.jfif" />
                    </div>
                </div>
            </div>
    </section>

</body>
</html>