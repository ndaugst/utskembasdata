<?php 
session_start();
require_once("config.php");

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_login_attempt'] = time();
}

$_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;

if ($_SESSION['login_attempts'] > 5) {
    die("Terlalu banyak percobaan. Coba lagi nanti yaa.");
}

if(isset($_POST['login'])){
    
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $sql = "SELECT * FROM users WHERE username=:username OR email=:email";
    $stmt = $db->prepare($sql);
    
    $params = array(
        ":username" => $username,
        ":email" => $username
    );

    $stmt->execute($params);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user){
        if(password_verify($password, $user["password"])){
            // buat Session
            session_start();
            session_regenerate_id(true);
            $_SESSION["user"] = $user;
            $_SESSION['login_attempts'] = 0;

            // login sukses, alihkan ke halaman timeline
            header("Location: timeline.php");
            exit;
        } else {
            $error = "password kamu salah tuu";
        }
    } else {
        $error = "ehh maaf minfess ga nemu username kamu nihh";
    }
}

function getUserIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    return $_SERVER['REMOTE_ADDR'];
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LOGIN GENG KAMBING</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --kambing-coklat: #8B4513;
            --kambing-putih: #F5F5DC;
            --kambing-hitam: #000000;
            --kambing-merah: #FF0000;
            --kambing-hijau: #2E8B57;
        }
        body {
            background-color: #f8f9fa;
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Comic Sans MS', cursive, sans-serif;
        }
        .kambing-card {
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            border: 3px solid var(--kambing-coklat);
            margin-top: 30px;
        }
        .kambing-header {
            background: var(--kambing-coklat);
            color: white;
            padding: 15px;
            text-align: center;
            border-bottom: 3px solid var(--kambing-hijau);
        }
        .kambing-title {
            font-size: 1.8rem;
            font-weight: bold;
        }
        
        .captcha-box {
            background: #EEE;
            border: 1px solid var(--kambing-coklat);
            border-radius: 5px;
            padding: 8px;
            font-family: 'Courier New', monospace;
            font-size: 20px;
            font-weight: bold;
            color: var(--kambing-hijau);
            text-align: center;
            margin: 10px 0;
        }
        .btn-kambing {
            background-color: var(--kambing-coklat);
            color: white;
            border: none;
            width: 100%;
            padding: 10px;
        }
        .error-message {
            background-color: #FFEBEE;
            border: 1px solid var(--kambing-merah);
            border-radius: 5px;
            padding: 8px;
            margin-bottom: 10px;
            color: var(--kambing-merah);
        }
    </style>
</head>

<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-xl-6 text-center mx-auto">
            <div class="kambing-card kambing-animation">
                <div class="kambing-header">
                    <h1 class="kambing-title">KAMBING LOGIN</h1>
                </div>
                <div class="card-body">
                    <?php if(isset($error)): ?>
                            <div class="error-message">
                                <?php echo $error; ?>
                            </div>
                    <?php endif; ?>
                </div>
        <p><a href="index.php">Home</a>

        <h4>Login</h4>
        <p>Belum punya akun? <a href="register.php">Daftar di sini dulu yaa</a></p>

        <form action="" method="POST">

            <div class="mb-3">
                <label for="username">Username</label>
                <input class="form-control" type="text" name="username" placeholder="Username atau email" required/>
            </div>

            <div class="mb-3">
                <label for="password">Password</label>
                <input class="form-control" type="password" name="password" placeholder="Password" required/>
            </div>

            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

            <button type="submit" class="btn btn-kambing" name="login">Masuk</button>
        </form>
            
        </div>

        <div class="col-md-6">
            <a href="register.php" style="color: var(--kambing-coklat);">Daftar akun baru</a>
        </div>

    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
   
</body>
</html>